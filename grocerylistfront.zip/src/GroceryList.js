import React, { Component } from 'react';
import Dropdown from './Dropdown.js';

class GroceryList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listGroceries: []
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    
    componentDidMount() {
        fetch('http://127.0.0.1:5000/groceryList').then(
            (response) => {
                response.json().then(
                    (json) => {
                        this.setState({listGroceries: json});
                    }
                );
            }
        );
    }

    addNewItem(newItem) {
        let addedList = this.state.listGroceries.push(newItem);
        this.setState({listGroceries: addedList})
    }

    handleChange(event) {
      let addedList = this.state.listGroceries.push(event.target.value);
      this.setState({listGroceries: addedList})
      //this.setState({value: event.target.value})
    }

    handleSubmit(event) {
      event.preventDefault();
    }

    render() {  
      const listItems = this.state.listGroceries.map((groceryItem) =>
          <li>{groceryItem}</li>
      );    
        return (
          <div>
            <form onSubmit={this.handleChange}>
              <input placeholder="Next Item" value={this.state.value} />
              <button type="submit">Add to List</button>
            </form>
            <ul>{listItems}</ul>
          </div>
        )
    }
}

export default GroceryList;